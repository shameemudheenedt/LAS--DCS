<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php include 'template.php'; ?>
<!DOCTYPE html>
<html>
  <head><title>LAS@DCS</title></head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">   
          <div class="col-md-3"></div>
	<div class="col-md-6  well">
            <form method="post" action="formreturn.php" id="demo-form2"  role="form" data-parsley-validate class="form-horizontal form-label-left  input_mask"> 
               <div class="form-group">
                       <label for="name" class="control-label col-md-4">Book ID:<span class="required">*</span></label>
                        <div class="col-md-8 col-sm-6 col-xs-12">
                          <input type="text" name="acc_code" class="form-control  has-feedback-left" data-inputmask="'mask' : '99999'" placeholder="Access Code">
                          <span class="fa fa-keyboard-o form-control-feedback left" aria-hidden="true"></span>
                        </div>
                </div>
               <div class="form-group">
                        <label for="name" class="control-label col-md-4">Student ID:<span class="required">*</span></label>
                        <div class="col-md-8 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="admno" class="form-control  has-feedback-left" data-inputmask="'mask' : '9999'" placeholder="Admission Number">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
               </div>
               <div class="form-group">
                <div class="col-sm-offset-4">
                   <button type="submit" name="submit" value="submit" class="btn btn-success btn-md">Return</button>
               </div>
               </div>
              </form>  
             <div class="clearfix"></div>
           </div>
        </div>         
        <!-- /page content -->
      </div>
    </div>
  </body>
</html>
