<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
          <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>All Available books</h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
             <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List<small>of the Books</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                    </p>
					<!--other wise table table-striped jambo_table bulk_action/table table-striped table-bordered dt-responsive nowrap-->
                    <table id="datatable-responsive" class="table table-striped jambo_table bulk_action" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Access Code</th>
                          <th>Title</th>
                          <th>Author</th>
                          <th>publisher</th>
                          <th>Topic</th>
                          <th>Edition</th>
                          <th>price</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php
                    $sql="SELECT * FROM book WHERE status='available'";
                    $run_sql=mysqli_query($conn,$sql);
                    while($rows = mysqli_fetch_array($run_sql)){
                        echo'
                        <tr>
                          <td>'.$rows['acc_code'].'</td>
                          <td>'.$rows['title'].'</td>
                          <td>'.$rows['author'].'</td>
                          <td>'.$rows['publisher'].'</td>
                          <td>'.$rows['topic'].'</td>
                          <td>'.$rows['edition'].'</td>
                          <td>'.$rows['price'].'</td>
                          <td><a  href="pjbook.php?book_id='.$rows['acc_code'].'" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>
                         </td>
                        </tr>
                        ';
                    }
                      ?>                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              </div>
              </div>
          </div>         
        <!-- /page content -->
      </div>
    </div>
  </body>
</html>
