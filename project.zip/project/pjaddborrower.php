<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>            
 <!DOCTYPE html>
<html lang="en">
  <head>
  <title>LAS@DCS</title>
  </head>
  <body class="nav-md">
    <div class="container body">
        <!-- page content -->   
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Add Member</h3>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Enter Details <small>of the Member</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form id="demo-form2" data-parsley-validate method="post" action="formaddborrower.php"  class="form-horizontal form-label-left  input_mask">
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="full-name">Full Name <span class="required">*</span>
                        </label>                        
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" class="form-control has-feedback-left" id="inputSuccess2" placeholder="First Name" name="fname" required>
                           <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Admission Number <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="admno" class="form-control  has-feedback-left" data-inputmask="'mask' : '9999'" placeholder="Admission Number" required>
                          <span class="fa fa-keyboard-o form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Phone Number</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" name="mob" class="form-control has-feedback-left" data-inputmask="'mask' : '(999) 999-9999'" placeholder="+91 8690875776" required>
                          <span class="glyphicon glyphicon-earphone form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Gender</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <div id="gender" class="btn-group" data-toggle="buttons">
                            <label class="btn btn-primary" data-toggle-class="btn-danger" data-toggle-passive-class="btn-default">
                              <input type="radio" name="gender" value="male" required> &nbsp; Male &nbsp;
                            </label>
                            <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                              <input type="radio" name="gender" value="female"> Female
                            </label>
                          </div>
                        </div>
                      </div><br>
                      
                      
                      <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Status *:</label>
                      <p>
                         Student:
                        <input type="radio" class="flat" name="status"  value="student" checked="" selected />
                         Teacher:
                        <input type="radio" class="flat" name="status"  value="teacher" required/>
                      </p> 
                        </div><br>
                      <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Academic Year *:</label>
                      <p>
                         1:
                        <input type="radio" class="flat" name="acyear" id="acyr1" value="1" required/>
                         2:
                        <input type="radio" class="flat" name="acyear" id="acyr2" value="2"/>
                         3:
                        <input type="radio" class="flat" name="acyear" id="acyr3" value="3"/> 
                         TC:
                        <input type="radio" class="flat" name="acyear" id="acyr4" value="4"/> 
                      </p> 
                        </div><br>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <button class="btn btn-primary" value="clear" type="reset">Reset</button>
                          <button type="submit" name="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                    <br><br><br>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /page content -->
      </div>
      </div>
  </body>
</html>
