<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head><title>LAS@DCS</title></head>
<body>
<?php 
include 'template.php';    
if(isset($_POST['submit']))
{
$acc_code=$_POST['acc_code'];  
$admno=$_POST['admno']; 
    
$sql="SELECT * FROM book WHERE acc_code=$acc_code";
$runs=mysqli_query($conn,$sql);
while($rows = mysqli_fetch_array($runs))
  {
    if($rows['status'] == 'issued')
      {
$ins_sql="DELETE FROM issuebook WHERE (admno='$admno' AND acc_code='$acc_code')";
$run_sql=mysqli_query($conn,$ins_sql);
    if($run_sql)
    {
        $query="UPDATE book SET status='available' WHERE acc_code='{$acc_code}'";
        $update_query=mysqli_query($conn,$query);
            if(!$update_query)
            {
            die("QUERY FAILED".mysqli_error($conn));
            }
            else
            {
            echo'<div class="container body">
            <div class="main_container">
            <div class="right_col" role="main">
            <div class="x_content bs-example-popovers">
            <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <h3>Book returned successfully.</h3>
            <h2><a href="pjallbooks.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Books</a></h2>
            </div></div></div></div></div>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            ';  
            }
    }
    else
    {
        echo'<center>Deletion not possible in which.!!</center>';
    }
  }
    else
    {
        echo'<div class="container body">
            <div class="main_container">
            <div class="right_col" role="main">
            <div class="x_content bs-example-popovers">
            <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <h3>Not a book in the issued list...!!</h3>
            <h2><a href="pjallbooks.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Books</a></h2>
            </div></div></div></div></div>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            ';  
    }
}   ///END while--Loop
}
else
{
    echo'<a href="pjissuebook1.php">Submission Failed...</a>';
}
?>
</body>
</html>
