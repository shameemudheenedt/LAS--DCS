<?php
$server='localhost';
$user='user';
$password='root';
$db='lms';
$conn=mysqli_connect($server,$user,$password,$db);
if(!$conn)
{
    die("Connection Failed".mysqli_connect_error());
}
?>