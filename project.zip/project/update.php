<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<link rel="icon" href="images/favicon.ico" type="image/ico" />
    <title>LMS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">
       <div class="container">
           <div class="jumbotron">
             <h1>Edit Member Details</h1>
           </div>
              <?php
            if(isset($_POST['submit2']))
                        { 
                            $fname=$_POST['fname'];
                            $admno=$_POST['admno'];
                            $gender=$_POST['gender']; 
                            $mob=$_POST['mob'];
                            $acyear=$_POST['acyear'];
                            $status=$_POST['status'];
                            $query="UPDATE borrower SET fname='{$fname}',admno='{$admno}',gender='{$gender}',status='{$status}',acyear='{$acyear}',mob='{$mob}' WHERE admno='{$admno}'";
                            $update_query=mysqli_query($conn,$query);
                      
                            if(!$update_query)
                            {
                                die("QUERY FAILED".mysqli_error($conn));
                            }
                else
                {
                  
                 echo'
                  <div class="x_content bs-example-popovers">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h3>Update Successfully Completed....!!!</h3>
                    <h2><a href="pjallborrower.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Borrowers</a></h2>
                  </div>
                  </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  ';    
                }
                         
                         
                        }
          // header("Location:pjallborrower.php");
           ?>
           <?php
           
           if(isset($_GET['edit_id']))
           {
             $sql="SELECT * FROM borrower WHERE admno = '$_GET[edit_id]'";
              $run_sql=mysqli_query($conn,$sql);
              while($rows = mysqli_fetch_assoc($run_sql))
              {
                  echo'
                  <form method="post" action="update.php">
                  <hr> 
                  <h4>
            <div class="row">
               <strong class="col-sm-3">Admission Number:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['admno'].'"  name="admno" readonly></div>
           </div><br>  
           <div class="row">
               <strong class="col-sm-3">Name:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['fname'].'"  name="fname"></div>
           </div><br>
            <div class="row">
               <strong class="col-sm-3">Gender:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['gender'].'"  name="gender"></div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Status:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['status'].'"  name="status"></div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Academic Year:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['acyear'].'"  name="acyear"></div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Mobile Number:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['mob'].'"  name="mob"></div>
           </div><br>
         <div class="row">
               <div class="col-sm-3">
               <button type="submit"  name="submit2" class="btn btn-success">Update</button>
               </div>
               </form>
           </div><br>            
           </h4>';
              }   
           }
               ?> 
       </div>
          </div>
        <!-- /page content -->
      </div>
    </div> 
  </body>
</html>
