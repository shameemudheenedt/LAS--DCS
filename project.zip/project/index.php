<?php
session_start();
include 'include/db.php';
$login_err = '';
if(isset($_GET['login_error']))
{
    
    if($_GET['login_error'] == 'empty')
    {
        $login_err = '<div class="alert alert-warning">
<h4><i class="fa fa-warning"></i> Warning!</h4> User name or password becomme<a href="#" class="alert-link">empty</a>..!!</div>';
    }
    elseif($_GET['login_error'] == 'wrong')
    {
        $login_err = '<div class="alert alert-warning"><h4><i class="fa fa-warning"></i> Warning!</h4> User name or password becomme<a href="#" class="alert-link"> wrong</a>..!!</div>';
    }
    elseif($_GET['login_error'] == 'query_error')
    {
        $login_err = '<div class="alert alert-warning"><h4><i class="fa fa-warning"></i> Warning!</h4>Some kind of<a href="#" class="alert-link">  Database Issue</a>..!!</div>';
    }
}
?>
<html>
  <head>
    <title>LAS@DCS</title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="../vendors/animate.css/animate.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>
  <body class="login">
   <?php 
      echo $login_err; ?>
      <a class="hiddenanchor" id="signin"></a>
      <div class="login_wrapper">
          <section class="login_content">  
           <form action="process.php" method="post">
              <h1>Login Librarian</h1>
              <div>
                <input type="text" class="form-control" name="uname" placeholder="User Name"/>
              </div>
              <div>
                <input type="password" class="form-control" name="password" placeholder="Password"/>
              </div>
              <div class="col-xl-12 col-sm-24 col-md-6">
                    <input class="btn btn-default submit" type="submit" value="login" name="login"/>
                  </div>
              <div class="clearfix"></div>
                <div>
                 <p>DCSNMSM GCK &copy;2025 All Rights Reserved.</p>
              </div>
            </form>
          </section>
        </div>
  </body>
</html>
