<?php include 'template.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title>
  </head>
  <body>
        <!-- page content -->
        <div class="right_col" role="main">             
 <div style="width:50px;height:50px;"></div>
   <div class="col-lg-10"></div>
   <div style="width:50px;height:50px;"></div>
    <div class="col-lg-10"></div>
   <div style="width:50px;height:50px;"></div>
      <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="col-md-3">
                     <img src="images/me.jpg" width="100%" class="img-thumbnail">
                </div>
                    <div class="col-md-7">
                        <h3><u>Shameemudheen</u></h3>
                        <p><i class="glyphicon glyphicon-education">&nbsp;Third BSc ComputerScience(2017-2019)</i></p>
                        <p><i class="glyphicon glyphicon-road">&nbsp;Nooramthode(P.O),Kodenchery,Calicut,PIN:673586,India</i></p>
                        <p><i class="glyphicon glyphicon-phone">&nbsp;8592895275</i></p>
                        <p><i class="glyphicon glyphicon-envelope">&nbsp;shmadv18@gmail.com</i></p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        <div class="col-lg-10"></div>
   <div style="width:50px;height:50px;"></div>
       <div class="col-lg-10"></div>
   <div style="width:50px;height:50px;"></div>
       <br>
        </div>
  </body>
</html>
       