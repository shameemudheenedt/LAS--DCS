<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">
       <div class="container">
           <div class="jumbotron">
             <h1>Book Details</h1>
               <p>Full Details</p>
           </div>
              <?php
           if(isset($_GET['book_id']))
           {
             $sql="SELECT * FROM book WHERE acc_code = '$_GET[book_id]'";
              $run_sql=mysqli_query($conn,$sql);
              while($rows = mysqli_fetch_assoc($run_sql))
              {
                  echo'<hr> 
                  <h4>
            <div class="row">
               <strong class="col-sm-3">Title:</strong>
               <div class="col-sm-3">'.$rows['title'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Access Code:</strong>
               <div class="col-sm-3">'.$rows['acc_code'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Publisher:</strong>
               <div class="col-sm-3">'.$rows['publisher'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Author:</strong>
               <div class="col-sm-3">'.$rows['author'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Topic:</strong>
               <div class="col-sm-3">'.$rows['topic'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Edition:</strong>
               <div class="col-sm-3">'.$rows['edition'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Price:</strong>
               <div class="col-sm-3">'.$rows['price'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Edition:</strong>
               <div class="col-sm-3">'.$rows['status'].'</div>
           </div><br>
           </h4>';
              }   
           }
               ?>   
       </div>
          </div>
        <!-- /page content -->
      </div>
    </div>   
  </body>
</html>
