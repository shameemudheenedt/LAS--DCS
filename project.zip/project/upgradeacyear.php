<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
if(isset($_GET['upgrade_id']))
{
    
$query="UPDATE borrower SET acyear='4' WHERE acyear='3'";
$update_query=mysqli_query($conn,$query);
    if($update_query)
        {
            echo'<center>Successfully Updated academic year(3 to 4)....!!!</center>'; 
            $query="UPDATE borrower SET acyear='3' WHERE acyear='2'";
            $update_query=mysqli_query($conn,$query);
        if($update_query)
            {
             echo'<center>Successfully Updated academic year(2 to 3)....!!!</center>'; 
             $query="UPDATE borrower SET acyear='2' WHERE acyear='1'";
             $update_query=mysqli_query($conn,$query);
            if($update_query)
              {
                echo'<center>Successfully Updated academic year(1 to 2)....!!!</center>'; 
              }
            else
              {                  
                die("QUERY FAILED".mysqli_error($conn));
              }
            }
            else
            {                
             die("QUERY FAILED".mysqli_error($conn));
            }
        }
        else
        {                        
         die("QUERY FAILED".mysqli_error($conn));
        }
     }

if(isset($_GET['degrade_id']))
{
    
$query="UPDATE borrower SET acyear='1' WHERE acyear='2'";
$update_query=mysqli_query($conn,$query);
    if($update_query)
        {
            echo'<center>Successfully Degrade academic year(2 to 1)....!!!</center>'; 
            $query="UPDATE borrower SET acyear='2' WHERE acyear='3'";
            $update_query=mysqli_query($conn,$query);
        if($update_query)
            {
             echo'<center>Successfully Degrade academic year(3 to 2)....!!!</center>'; 
             $query="UPDATE borrower SET acyear='3' WHERE acyear='4'";
             $update_query=mysqli_query($conn,$query);
            if($update_query)
              {
                echo'<center>Successfully Degrade academic year(4 to 3)....!!!</center>'; 
              }
            else
              {                  
                die("QUERY FAILED".mysqli_error($conn));
              }
            }
            else
            {                
             die("QUERY FAILED".mysqli_error($conn));
            }
        }
        else
        {                        
         die("QUERY FAILED".mysqli_error($conn));
        }
     }


?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<link rel="icon" href="images/favicon.ico" type="image/ico" />
    <title>LMS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
          <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Academic Details Upgrade</h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
             <div class="col-md-12 col-sm-12 col-xs-12">
               <script>
               function func() {
                  confirm("Press OK to Update.")  
               }  
               </script>
                <div class="x_panel">
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Update Academic Year:</label>
                      </div>
                      <?php
                    $sql="SELECT acyear FROM borrower";
                    $run=mysqli_query($conn,$sql);
                    $rows = mysqli_fetch_array($run);
                        echo'
                          <a onClick="func()" href="upgradeacyear.php?upgrade_id='.$rows['acyear'].'" class="btn btn-danger btn-md">Upgrade </a>
                        ';
                      ?>
                  </div>
                </div>
              </div>
              
              <div class="row">
             <div class="col-md-12 col-sm-12 col-xs-12">
                <script>
               function func2() {
                  confirm("Press OK to Degrade.")  
               }  
               </script>
                <div class="x_panel">
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Degrade Academic Year:</label>
                      </div>
                      <?php
                    $sql="SELECT acyear FROM borrower";
                    $run=mysqli_query($conn,$sql);
                    $rows = mysqli_fetch_array($run);
                        echo'
                          <a onClick="func2()" href="upgradeacyear.php?degrade_id='.$rows['acyear'].'" class="btn btn-danger btn-md">Degrade </a>
                        ';
                      ?>
                  </div>
                </div>
              </div>
              
              </div>
              </div>
          </div>         
        <!-- /page content -->
      </div>
    </div>    
  </body>
</html>







