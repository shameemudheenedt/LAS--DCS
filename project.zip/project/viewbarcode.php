<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LMS</title> 
    <script src="js/jquery.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
  </head>
  <body>
<table class="table">
<tbody>
 <tr><td><?php include 'generate.php';  ?></td>
     <td><?php include 'generate.php';  ?></td>
     <td><?php include 'generate.php';  ?></td>
 </tr>
</tbody>
</table>
</body>
</html>
