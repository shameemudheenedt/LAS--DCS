<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LAS@DCS</title>
</head>
<body>
<?php
    include 'template.php';
if(isset($_POST['submit']))
{
$name=strip_tags($_POST['fname']);
$gender=$_POST['gender'];
$status=$_POST['status'];
$mob=strip_tags($_POST['mob']);    
$acyear=$_POST['acyear'];  
$admno=$_POST['admno'];      
$ins_sql="INSERT INTO borrower (admno,fname,gender,status,acyear,mob) VALUES ('$admno','$name','$gender','$status','$acyear','$mob')";
$run_sql=mysqli_query($conn,$ins_sql);
    if($run_sql)
    {
         echo'<div class="container body">
      <div class="main_container">
        <div class="right_col" role="main">
                  <div class="x_content bs-example-popovers">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h3>Member inserted.</h3>
                    <h2><a href="pjallborrower.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Members</a></h2>
                  </div>
                  </div>
                   </div>
                   </div> </div>
                  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  ';  
    }
    else
    {
         echo'<div class="container body">
      <div class="main_container">
        <div class="right_col" role="main">
                  <div class="x_content bs-example-popovers">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h3>Member not inserted.</h3>
                    <h2><a href="pjallborrower.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Members</a></h2>
                  </div>
                  </div>
                   </div>
                   </div> </div>
                  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  ';  
    }
}
else
{
    echo'<a href="pjaddborrower.php">Empty fields are present...</a>';
}
?>
</body>
</html>
