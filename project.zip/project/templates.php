<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>            
<?php include 'template.php'; ?>
 <!DOCTYPE html>
<html lang="en">
  <head>
  <title>LMS</title>
  </head>
  <body class="nav-md">
    <div class="container body">
        <!-- page content -->   
        <div class="right_col" role="main">
              <div class="x_content bs-example-popovers">
                  <div class="alert alert-default alert-dismissible fade in" role="alert">
                  <font color="white">
                        <h1><center><b>LAS@DCS</b></center></h1>
             <h3><center>LIBRARY AUTOMATION SYSTEM,DEPARTMENT OF COMPUTER SCIENCE</center></h3>
             <h2><center>NMSM&nbsp;&nbsp;&nbsp;Govt.&nbsp;&nbsp;&nbsp;COLLEGE&nbsp;&nbsp;&nbsp;KALPETTA</center></h2>
                  </font>
                  <div class="col-sm-2"></div><div class="col-sm-2"></div>
	<div class="col-md-6">
                      <img src="images/shm.png" width="58%"   class="img-circle">
                  </div>
           
             </div>
            </div>
        <!-- /page content -->
      </div>
      </div>
  </body>
</html>
