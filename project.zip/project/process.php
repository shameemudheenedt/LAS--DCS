<?php
session_start();
include 'include/db.php';
if(isset($_POST['login']))
   {
       if(!empty($_POST['uname']) && !empty($_POST['password']))
       {
         $getuname=mysqli_real_escape_string($conn,$_POST['uname']);
         $getpassword=mysqli_real_escape_string($conn,$_POST['password']);
         $sql="SELECT * FROM user WHERE uname = '$getuname' AND password = '$getpassword' ";
           if($result = mysqli_query($conn,$sql))
           {
               if(mysqli_num_rows($result) > 0)
               {
                   $_SESSION['uname']=$getuname;
                   $_SESSION['password']=$getpassword;
                   header('Location:templates.php');
               }
               else
               {
                 header('Location:index.php?login_error=wrong');   
               }
           }
           else
           {
               header('Location:index.php?login_error=query_error');
           }
       }
       else
       {
            header('Location:index.php?login_error=empty');
       }
   }
   else
   {
      
   }
?>