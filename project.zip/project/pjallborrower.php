<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
          <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>All Member Details</h3>
             </div>
             <div class="title_right">   
        <form class="panel-group form-horizontal" action="searchborrower.php" role="form">
               <div class="col-sm-6">
                            <label for="heard">Search by *</label>
                  
                          <select id="heard" class="form-control" name="choice" required>
                            <option value="">Choice..</option>
                            <option value="admno">Admission Number</option>
                            <option value="fname">Name</option>
                            <option value="gender">Gender</option>
                            <option value="status">Status</option>
                            <option value="mob">Mobile</option>
                            <option value="acyear">Academic Year</option>
              </select>
                    </div>     
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="search" name="search" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" name="search_submit" type="submit">Go!</button>
                    </span>
                  </div>
                </div>
                
        </form>   
             </div>            
              
            </div>
            <div class="clearfix"></div>
            <div class="row">
             <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List<small>all Members</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
					<!--other wise table table-striped jambo_table bulk_action/table table-striped table-bordered dt-responsive nowrap-->
                    <table id="datatable-responsive" class="table table-striped jambo_table bulk_action" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Admission Number</th>
                          <th>Name</th>
                          <th>Gender</th>
                          <th>Status</th>
                          <th>Academic Year</th>
                          <th>Mobile Number</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                    $sql="SELECT * FROM borrower";
                    $run_sql=mysqli_query($conn,$sql);
                    while($rows = mysqli_fetch_array($run_sql)){
                        echo'
                        <tr>
                          <td>'.$rows['admno'].'</td>
                          <td>'.$rows['fname'].'</td>
                          <td>'.$rows['gender'].'</td>
                          <td>'.$rows['status'].'</td>
                          <td>'.$rows['acyear'].'</td>
                          <td>'.$rows['mob'].'</td>
                          <td><a  href="pjborrower.php?user_id='.$rows['admno'].'" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View details</a></td>
                        </tr>
                        ';
                    }
                      ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              </div>
              </div>
          </div>         
        <!-- /page content -->
      </div>
    </div>  
  </body>
</html>
