<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>LAS@DCS</title>
</head>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">
       <div class="container">        
<?php 
if(isset($_POST['submit6']))
{
$acc_code=$_POST['acc_code'];
$date=$_POST['date'];     
$admno=$_POST['admno'];    
$sql="SELECT * FROM book WHERE acc_code=$acc_code";
$runs=mysqli_query($conn,$sql);
while($rows = mysqli_fetch_array($runs))
  {
    if($rows['status'] == 'available')
      {
        $ins_sql="INSERT INTO issuebook (admno,acc_code,date) VALUES ('$admno','$acc_code','$date')";
        $run_sql=mysqli_query($conn,$ins_sql);
       if($run_sql)
         {
          echo'<div class="x_content bs-example-popovers">
          <div class="alert alert-success alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <h3>Book issued.</h3></div></div><br><br><br><br><br><br><br><br><br><br><br><br><br><br>';
          $query="UPDATE book SET status='issued' WHERE acc_code='{$acc_code}'";
          $update_query=mysqli_query($conn,$query);
          if(!$update_query)
            {
             die("QUERY FAILED".mysqli_error($conn));
            }
          else
            {
             echo'<center><h3>Update Successfully Completed....!!!</h3><h2><a href="pjallbooks.php" class="btn btn-success btn-md"><i class="fa fa-check"></i>Goto to all Books</a></h2><center><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>';
            }
         }
        else
        {
            echo"<center>Insertion failed....!!</center>";
        }
      }
      else
      {
         echo'<div class="x_content bs-example-popovers">
          <div class="alert alert-success alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <h3>Selected book is  issued book.</h3></div>
          </div><br>';
      }
  }
} 
else
{
    echo'<a href="pjissuebook1.php">Submission Failed present...</a>';
}
?>
</div></div></div></div>
</body>
</html>
