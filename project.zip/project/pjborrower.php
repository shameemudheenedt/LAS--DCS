<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">
       <div class="container">
           <div class="jumbotron">
             <h1>Member Details</h1>
               <p>Full Details</p>
           </div>
              <?php
           if(isset($_GET['user_id']))
           {
             $sql="SELECT * FROM borrower WHERE admno = '$_GET[user_id]'";
              $run_sql=mysqli_query($conn,$sql);
              while($rows = mysqli_fetch_assoc($run_sql))
              {
                  echo'<hr> 
                  <h4>
            <div class="row">
               <strong class="col-sm-3">Name:</strong>
               <div class="col-sm-3">'.$rows['fname'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Admission Number:</strong>
               <div class="col-sm-3">'.$rows['admno'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Gender:</strong>
               <div class="col-sm-3">'.$rows['gender'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Academic Year:</strong>
               <div class="col-sm-3">'.$rows['acyear'].'</div>
           </div><br>
           <div class="row">
               <strong class="col-sm-3">Mobile Number:</strong>
               <div class="col-sm-3">'.$rows['mob'].'</div>
           </div>
           </h4>
           <br><br><br><br>
           ';
              }   
           }
               ?>
            <div class="page-title">
              <div class="title_left">
                <h3>All pending books</h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
             <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List<small>of the Books</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                    </p>
                    <table id="datatable-responsive" class="table table-striped jambo_table bulk_action" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Access Code</th>
                          <th>Admission Number</th>
                          <th>Date</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php
                    $sql="SELECT * FROM issuebook WHERE admno =$_GET[user_id]";
                    $run_sql=mysqli_query($conn,$sql);
                    while($rows = mysqli_fetch_array($run_sql)){
                        echo'
                        <tr>
                          <td>'.$rows['acc_code'].'</td>
                          <td>'.$rows['admno'].'</td>
                          <td>'.$rows['date'].'</td>
                          <td><center><a href="pjreturn1.php" class="btn btn-primary btn-md">Return</a></center></td>
                        </tr>
                        ';
                    }
                      ?>                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              </div>
          <hr>     
       </div>
          </div>   
        <!-- /page content -->
      </div>
    </div>
  </body>
</html>
