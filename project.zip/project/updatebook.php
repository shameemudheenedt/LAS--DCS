<?php
session_start();
include 'include/db.php';
include 'template.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index..php'); 
        }
    }
}
else
{
     header('Location:index..php'); 
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<link rel="icon" href="images/favicon.ico" type="image/ico" />
    <title>LMS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">
       <div class="container">
           <div class="jumbotron">
             <h1>Update Book Details</h1>
               <p>Full Details</p>
           </div>
               <?php
            if(isset($_POST['submitbook']))
                        { 
                            $title=$_POST['title'];
                            $acc_code=$_POST['acc_code'];
                            $publisher=$_POST['publisher']; 
                            $author=$_POST['author'];
                            $topic=$_POST['topic'];
                            $edition=$_POST['edition'];
                            $price=$_POST['price'];
                            $status=$_POST['status'];
                            $query="UPDATE book SET title='{$title}',publisher='{$publisher}',author='{$author}',topic='{$topic}',edition='{$edition}',price='{$price}',status='{$status}' WHERE acc_code='{$acc_code}'";
                            $update_query=mysqli_query($conn,$query);
                      
                            if(!$update_query)
                            {
                                die("QUERY FAILED".mysqli_error($conn));
                            }
                else
                {
                 echo'
                  <div class="x_content bs-example-popovers">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h3>Update Successfully Completed....!!!</h3>
                    <h2><a href="pjallbooks.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Books</a></h2>
                  </div>
                  </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  ';
                }  
                        }
          // header("Location:pjallbook.php");
           ?>
              <?php
           if(isset($_GET['book_id']))
           {
             $sql="SELECT * FROM book WHERE acc_code = '$_GET[book_id]'";
              $run_sql=mysqli_query($conn,$sql);
              while($rows = mysqli_fetch_assoc($run_sql))
              {
                  echo'
                   <form method="post" action="updatebook.php">
                  <hr> 
                  <h4>
            <div class="row">
               <strong class="col-sm-3">Access Code:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['acc_code'].'"  name="acc_code" readonly></div>
           </div><br> 
            <div class="row">
               <strong class="col-sm-3">Title:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['title'].'"  name="title"></div>
           </div><br>  
            <div class="row">
               <strong class="col-sm-3">Publisher:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['publisher'].'"  name="publisher"></div>
           </div><br>  
           <div class="row">
               <strong class="col-sm-3">Author:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['author'].'"  name="author"></div>
           </div><br>      
            <div class="row">
               <strong class="col-sm-3">Topic:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['topic'].'"  name="topic"></div>
           </div><br> 
            <div class="row">
               <strong class="col-sm-3">Edition:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['edition'].'"  name="edition"></div>
           </div><br> 
            <div class="row">
               <strong class="col-sm-3">Price:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['price'].'"  name="price"></div>
           </div><br> 
            <div class="row">
               <strong class="col-sm-3">Edition:</strong>
               <div class="col-sm-3">
               <input type="text" class="form-control has-feedback-left" id="inputSuccess2" value="'.$rows['status'].'"  name="status"></div>
           </div><br>
           <div class="row">
               <div class="col-sm-3">
               <button type="submit"  name="submitbook" class="btn btn-success">Update</button>
               </div>
               </form>
           </div><br>   
           </h4><br><br><br><br>';
              }   
           }
               ?>
       </div>
          </div>
        <!-- /page content -->
      </div>
    </div> 
  </body>
</html>
