<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
if(isset($_POST['submit1']))
{
$code=$_POST['acc_code'];
$title=$_POST['title'];
$publisher=strip_tags($_POST['publisher']);    
$author=$_POST['author'];  
$topic=$_POST['topic'];      
$edition=$_POST['edition']; 
$price=$_POST['price']; 
$status=$_POST['status']; 
$ins_sql="INSERT INTO book (acc_code,title,publisher,author,topic,edition,price,status) VALUES ('$code','$title','$publisher','$author','$topic','$edition','$price','$status')";
$run_sql=mysqli_query($conn,$ins_sql);
    if($run_sql)
    {
         echo'<div class="container body">
      <div class="main_container">
        <div class="right_col" role="main">
                  <div class="x_content bs-example-popovers">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h3>Book inserted.</h3>
                    <h2><a href="pjallbooks.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Books</a></h2>
                  </div>
                  </div>
                   </div>
                   </div> </div>
                  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  ';      
}
    else{
        echo'<div class="container body">
      <div class="main_container">
        <div class="right_col" role="main">
                  <div class="x_content bs-example-popovers">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h3>Book not inserted.</h3>
                    <h2><a href="pjallbooks.php" class="btn btn-primary btn-md"><i class="fa fa-check"></i>Goto to all Books</a></h2>
                  </div>
                  </div>
                   </div>
                   </div> </div>
                  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  ';  
    }
}
?>
