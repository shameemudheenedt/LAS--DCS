<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Add Book</h3>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Enter Details <small>of the Book</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form method="post" action="formaddbook.php" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left  input_mask">

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="book_title">Book Title<span class="required">*</span>
                        </label>                        
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" class="form-control has-feedback-left" name="title" id="inputSuccess2" placeholder="Book Title" required>
                           <span class="fa fa-book form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Author">Author<span class="required">*</span>
                        </label>                        
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" class="form-control has-feedback-left" name="author" id="inputSuccess2" placeholder="Author" required>
                           <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Publisher">Publisher<span class="required">*</span>
                        </label>                        
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="publisher" class="form-control has-feedback-left" id="inputSuccess2" placeholder="publisher" required>
                           <span class="fa fa-newspaper-o form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                     
                         <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price">Price<span class="required">*</span>
                        </label>                        
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="price" class="form-control has-feedback-left" id="inputSuccess2" placeholder="price" required>
                           <span class="fa fa-inr form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="edition">Edition<span class="required" required>*</span>
                        </label>                        
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="edition" class="form-control has-feedback-left" id="inputSuccess2" placeholder="edition">
                           <span class=" glyphicon glyphicon-tags form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Access Code <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" name="acc_code" class="form-control  has-feedback-left" data-inputmask="'mask' : '99999'" placeholder="Access Code">
                          <span class="fa fa-keyboard-o form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12">Topic</label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <textarea class="resizable_textarea form-control" name="topic" placeholder="Enter the Topics"></textarea>
                    </div>
                  </div>
                     <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12">Status *:</label>
                      <p>
                         Available:
                        <input type="radio" class="flat" name="status" id="acyr1" value="available" checked="" selected />
                         Issued:
                        <input type="radio" class="flat" name="status" id="acyr2" value="issued" required/>
                         Reference:
                        <input type="radio" class="flat" name="status" id="acyr3" value="reference" required/>
                         Damaged:
                        <input type="radio" class="flat" name="status" id="acyr3" value="damage" required/> 
                      </p> 
                        </div><br>
                     
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <button class="btn btn-primary" value="clear" type="reset">Reset</button>
                          <button type="submit" name="submit1" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                    <br><br><br>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
      </div>
  </body>
</html>
