<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title>
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="right_col" role="main">   
          <div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary"><center>Barcode Generator</center></h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<form method="POST" action="viewbarcodem.php">
				<div class="form-group">
					<label>Enter the Member ID:</label>
					<input type="text" class="form-control" name="barcode"/>
					<br />
					<center><button class="btn btn-primary" name="generate">Generate</button></center>
					<br />
					<?php include 'generate.php'; ?>
				</div>
			</form>
		</div>
	</div>
             <div class="clearfix"></div>
           </div>
        </div>         
        <!-- /page content -->
      </div>
  </body>
</html>
