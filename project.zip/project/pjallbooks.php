<?php
session_start();
include 'include/db.php';
if(isset($_SESSION['uname']) && isset($_SESSION['password']) == true)
{
    $sel_sql = "SELECT * FROM user WHERE uname = '$_SESSION[uname]' AND password = '$_SESSION[password]'";
    if($run_sql = mysqli_query($conn,$sel_sql))
    {
        if(mysqli_num_rows($run_sql) == 1)
        {
            
        }
        else
        {
             header('Location:index.php'); 
        }
    }
}
else
{
     header('Location:index.php'); 
}
?>
<?php
include 'template.php';
if(isset($_GET['del_id']))
{
    $del_sql="DELETE FROM book WHERE   acc_code='$_GET[del_id]'";
    $run_sql =mysqli_query($conn,$del_sql);
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LAS@DCS</title> 
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- page content -->
          <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>All books Details</h3>
              </div>
              <div class="title_right">
        <form class="panel-group form-horizontal" action="searchbook.php" role="form">
               <div class="col-sm-6">
                            <label for="heard">Search by *</label>
                  
                          <select id="heard" class="form-control" name="choice" required>
                            <option value="">Choice..</option>
                            <option value="acc_code">Access code</option>
                            <option value="title">Book Title</option>
                            <option value="publisher">Publisher</option>
                            <option value="author">Auther</option>
                            <option value="topic">Topic</option>
                            <option value="edition">Edition</option>
                            <option value="price">Price</option>
                            <option value="status">Status</option>
              </select>
                    </div>  
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="search" name="search" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" name="search_submit" type="submit">Go!</button>
                    </span>
                  </div>
                </div>
        </form>               
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
             <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List<small>of the Books</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                    </p>
					<!--other wise table table-striped jambo_table bulk_action/table table-striped table-bordered dt-responsive nowrap-->
                    <table id="datatable-responsive" class="table table-striped jambo_table bulk_action" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Access Code</th>
                          <th>Title</th>
                          <th>Author</th>
                          <th>publisher</th>
                          <th>Topic</th>
                          <th>Edition</th>
                          <th>price</th>
                          <th>Availability</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php
                    $sql="SELECT * FROM book";
                    $run_sql=mysqli_query($conn,$sql);
                    while($rows = mysqli_fetch_array($run_sql)){
                        echo'
                        <tr>
                          <td>'.$rows['acc_code'].'</td>
                          <td>'.$rows['title'].'</td>
                          <td>'.$rows['author'].'</td>
                          <td>'.$rows['publisher'].'</td>
                          <td>'.$rows['topic'].'</td>
                          <td>'.$rows['edition'].'</td>
                          <td>'.$rows['price'].'</td>
                          <td>'.$rows['status'].'</td>
                          <td><a  href="pjbook.php?book_id='.$rows['acc_code'].'" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>
                           <script>
                         function funcdel() 
                         {
                         confirm("Press OK to Delete.")  
                         }  
                        </script>
                            <a onClick="funcdel()" href="pjallbooks.php?del_id='.$rows['acc_code'].'" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a></td>
                        </tr>
                        ';
                    }
                      ?>                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              </div>
              </div>
          </div>         
        <!-- /page content -->
      </div>
    </div>
  </body>
</html>
